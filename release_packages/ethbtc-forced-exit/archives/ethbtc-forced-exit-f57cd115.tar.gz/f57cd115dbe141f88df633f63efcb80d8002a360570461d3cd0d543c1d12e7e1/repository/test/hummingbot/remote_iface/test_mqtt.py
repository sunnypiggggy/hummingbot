import asyncio
import threading
from decimal import Decimal
from test.mock.mock_mqtt_server import FakeMQTTBroker
from typing import Awaitable
from unittest import TestCase
from unittest.mock import AsyncMock, MagicMock, patch

from async_timeout import timeout

from hummingbot.client.config.client_config_map import ClientConfigMap
from hummingbot.client.config.config_helpers import ClientConfigAdapter
from hummingbot.client.config.config_var import ConfigVar
from hummingbot.client.hummingbot_application import HummingbotApplication
from hummingbot.connector.test_support.mock_paper_exchange import MockPaperExchange
from hummingbot.core.data_type.common import OrderType, TradeType
from hummingbot.core.data_type.limit_order import LimitOrder
from hummingbot.core.event.events import BuyOrderCreatedEvent, MarketEvent, OrderExpiredEvent, SellOrderCreatedEvent
from hummingbot.model.order import Order
from hummingbot.model.trade_fill import TradeFill
from hummingbot.remote_iface.mqtt import MQTTGateway, MQTTMarketEventForwarder


class RemoteIfaceMQTTTests(TestCase):
    # logging.Level required to receive logs from the exchange
    level = 0

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.instance_id = 'TEST_ID'
        cls.fake_err_msg = "Some error"

        cls.command_topics = [
            'start',
            'stop',
            'config',
            'import',
            'status',
            'history',
            'balance/limit',
            'balance/paper',
        ]
        cls.START_URI = 'hbot/$instance_id/start'
        cls.STOP_URI = 'hbot/$instance_id/stop'
        cls.CONFIG_URI = 'hbot/$instance_id/config'
        cls.IMPORT_URI = 'hbot/$instance_id/import'
        cls.STATUS_URI = 'hbot/$instance_id/status'
        cls.HISTORY_URI = 'hbot/$instance_id/history'
        cls.BALANCE_LIMIT_URI = 'hbot/$instance_id/balance/limit'
        cls.BALANCE_PAPER_URI = 'hbot/$instance_id/balance/paper'

    def setUp(self) -> None:
        super().setUp()

        self._original_async_loop = asyncio.get_event_loop()
        self.async_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.async_loop)

        self.client_config_map = ClientConfigAdapter(ClientConfigMap())
        self.client_config_map.instance_id = self.instance_id
        self.hbapp = HummingbotApplication(client_config_map=self.client_config_map)
        self.client_config_map.mqtt_bridge.mqtt_port = 1888
        self.client_config_map.mqtt_bridge.mqtt_commands = 1
        self.client_config_map.mqtt_bridge.mqtt_events = 1

        self.log_records = []
        self.fake_mqtt_broker = FakeMQTTBroker()

        # Inject the fake aiomqtt client transport.
        def _fake_create_client(gw):
            return self.fake_mqtt_broker.create_client()
        self.create_client_patcher = patch(
            'hummingbot.remote_iface.mqtt.MQTTGateway._create_client',
            _fake_create_client
        )
        self.addCleanup(self.create_client_patcher.stop)
        self.create_client_patcher.start()
        # Hard guard: a real broker connection must never be attempted in tests.
        # If any code path bypasses the _create_client seam, fail loudly instead
        # of opening a socket (CI runners have no MQTT broker).
        self.no_network_patcher = patch(
            'hummingbot.remote_iface.mqtt.aiomqtt.Client',
            side_effect=AssertionError(
                "Real aiomqtt.Client instantiated in tests — network access attempted")
        )
        self.addCleanup(self.no_network_patcher.stop)
        self.no_network_patcher.start()
        # MQTT Patch Loggers Patcher
        self.patch_loggers_patcher = patch(
            'hummingbot.remote_iface.mqtt.MQTTGateway.patch_loggers'
        )
        self.addCleanup(self.patch_loggers_patcher.stop)
        self.patch_loggers_mock = self.patch_loggers_patcher.start()
        self.patch_loggers_mock.return_value = None

        self.gateway = MQTTGateway(self.hbapp)
        # Reconnect instantly in tests.
        self.gateway._reconnect_interval = 0.0
        self.test_market: MockPaperExchange = MockPaperExchange()
        self.hbapp.trading_core.connector_manager.connectors["test_market_paper_trade"] = self.test_market
        # No strategy loaded by default (the app no longer initializes this attribute).
        self.hbapp.strategy = None
        self.resume_test_event = asyncio.Event()
        self.hbapp.logger().setLevel(1)
        self.hbapp.logger().addHandler(self)
        self.gateway.logger().setLevel(1)
        self.gateway.logger().addHandler(self)

    def tearDown(self):
        self.async_loop.run_until_complete(asyncio.sleep(0.1))
        self.gateway.stop()
        del self.gateway
        self.async_loop.run_until_complete(asyncio.sleep(0.1))
        self.fake_mqtt_broker.clear()
        self.create_client_patcher.stop()
        self.patch_loggers_patcher.stop()

        self.async_loop.stop()
        self.async_loop.close()
        asyncio.set_event_loop(self._original_async_loop)

        super().tearDown()

    def handle(self, record):
        self.log_records.append(record)

    def _is_logged(self, log_level: str, message: str) -> bool:
        return any(
            record.levelname == log_level and str(record.getMessage()) == str(message) for record in self.log_records)

    async def wait_for_logged(self, log_level: str, message: str):
        try:
            async with timeout(3):
                while not self._is_logged(log_level=log_level, message=message):
                    await asyncio.sleep(0.1)
        except asyncio.TimeoutError as e:
            print(f"Message: {message} was not logged.")
            print(f"Received Logs: {[record.getMessage() for record in self.log_records]}")
            raise e

    def async_run_with_timeout(self, coroutine: Awaitable, timeout: float = 1):
        ret = self.async_loop.run_until_complete(asyncio.wait_for(coroutine, timeout))
        return ret

    async def wait_for_connected(self):
        async with timeout(3):
            while not self.fake_mqtt_broker.is_connected:
                await asyncio.sleep(0.05)

    async def wait_for_subscriptions(self, count: int):
        async with timeout(3):
            while len(self.fake_mqtt_broker.subscriptions) < count:
                await asyncio.sleep(0.05)

    async def _create_exception_and_unlock_test_with_event_async(self, *args, **kwargs):
        self.resume_test_event.set()
        raise RuntimeError(self.fake_err_msg)

    def _create_exception_and_unlock_test_with_event(self, *args, **kwargs):
        self.resume_test_event.set()
        raise RuntimeError(self.fake_err_msg)

    def _create_exception_and_unlock_test_with_event_not_impl(self, *args, **kwargs):
        self.resume_test_event.set()
        raise NotImplementedError(self.fake_err_msg)

    def is_msg_received(self, *args, **kwargs):
        return self.fake_mqtt_broker.is_msg_received(*args, **kwargs)

    async def wait_for_rcv(self, topic, content=None, msg_key='msg'):
        try:
            async with timeout(3):
                while not self.is_msg_received(topic=topic, content=content, msg_key=msg_key):
                    await asyncio.sleep(0.1)
        except asyncio.TimeoutError as e:
            print(f"Topic: {topic} was not received.")
            print(f"Received Messages: {self.fake_mqtt_broker.received_msgs}")
            raise e

    def start_mqtt(self):
        self.gateway.start()
        self.gateway.start_market_events_fw()

    def get_topic_for(
            self,
            topic
    ):
        return topic.replace('$instance_id', self.hbapp.instance_id)

    def build_fake_strategy(
            self,
            status_check_all_mock: MagicMock,
            load_strategy_config_map_from_file: MagicMock,
            invalid_strategy: bool = True,
            empty_name: bool = False
    ):
        if empty_name:
            strategy_name = ''
        elif invalid_strategy:
            strategy_name = "some_strategy"
        else:
            strategy_name = "avellaneda_market_making"
        status_check_all_mock.return_value = True
        strategy_conf_var = ConfigVar("strategy", None)
        strategy_conf_var.value = strategy_name
        load_strategy_config_map_from_file.return_value = {"strategy": strategy_conf_var}
        return strategy_name

    def send_fake_import_cmd(
            self,
            status_check_all_mock: MagicMock,
            load_strategy_config_map_from_file: MagicMock,
            invalid_strategy: bool = True,
            empty_name: bool = False
    ):
        import_topic = self.get_topic_for(self.IMPORT_URI)

        strategy_name = self.build_fake_strategy(
            status_check_all_mock=status_check_all_mock,
            load_strategy_config_map_from_file=load_strategy_config_map_from_file,
            invalid_strategy=invalid_strategy,
            empty_name=empty_name
        )

        self.fake_mqtt_broker.publish_to_subscription(import_topic, {'strategy': strategy_name})

    @staticmethod
    def emit_order_created_event(
            market: MockPaperExchange,
            order: LimitOrder
    ):
        event_cls = BuyOrderCreatedEvent if order.is_buy else SellOrderCreatedEvent
        event_tag = MarketEvent.BuyOrderCreated if order.is_buy else MarketEvent.SellOrderCreated
        market.trigger_event(
            event_tag,
            message=event_cls(
                order.creation_timestamp,
                OrderType.LIMIT,
                order.trading_pair,
                order.quantity,
                order.price,
                order.client_order_id,
                order.creation_timestamp * 1e-6
            )
        )

    @staticmethod
    def emit_order_expired_event(market: MockPaperExchange):
        event_cls = OrderExpiredEvent
        event_tag = MarketEvent.OrderExpired
        market.trigger_event(
            event_tag,
            message=event_cls(
                1671819499,
                "OID1"
            )
        )

    def build_fake_trades(self):
        ts = 1671819499
        config_file_path = "some-strategy.yml"
        strategy_name = "pure_market_making"
        market = "binance"
        symbol = "HBOT-COINALPHA"
        base_asset = "HBOT"
        quote_asset = "COINALPHA"
        order_id = "OID1"
        order = Order(
            id=order_id,
            config_file_path=config_file_path,
            strategy=strategy_name,
            market=market,
            symbol=symbol,
            base_asset=base_asset,
            quote_asset=quote_asset,
            creation_timestamp=0,
            order_type="LMT",
            amount=4,
            leverage=0,
            price=Decimal(1000),
            last_status="PENDING",
            last_update_timestamp=0,
        )
        trades = [
            TradeFill(
                config_file_path=config_file_path,
                strategy=strategy_name,
                market=market,
                symbol=symbol,
                base_asset=base_asset,
                quote_asset=quote_asset,
                timestamp=ts,
                order_id=order_id,
                trade_type=TradeType.BUY.name,
                order_type=OrderType.LIMIT.name,
                price=Decimal(1000),
                amount=Decimal(1),
                trade_fee='{}',
                exchange_trade_id="EOID1",
                order=order),
            TradeFill(
                config_file_path=config_file_path,
                strategy=strategy_name,
                market=market,
                symbol=symbol,
                base_asset=base_asset,
                quote_asset=quote_asset,
                timestamp=ts,
                order_id=order_id,
                trade_type=TradeType.BUY.name,
                order_type=OrderType.LIMIT.name,
                price=Decimal(1000),
                amount=Decimal(1),
                trade_fee='{}',
                exchange_trade_id="EOID1",
                order=order)
        ]
        trade_list = list([TradeFill.to_bounty_api_json(t) for t in trades])
        for t in trade_list:
            t['trade_timestamp'] = str(t['trade_timestamp'])
        return trade_list

    @patch("hummingbot.client.command.balance_command.BalanceCommand.balance")
    def test_mqtt_command_balance_limit_failure(
            self,
            balance_mock: MagicMock
    ):
        balance_mock.side_effect = self._create_exception_and_unlock_test_with_event
        self.start_mqtt()

        msg = {
            'exchange': 'binance',
            'asset': 'BTC-USD',
            'amount': '1.0',
        }

        self.fake_mqtt_broker.publish_to_subscription(self.get_topic_for(self.BALANCE_LIMIT_URI), msg)

        topic = f"test_reply/hbot/{self.instance_id}/balance/limit"
        msg = {'status': 400, 'msg': self.fake_err_msg, 'data': ''}
        self.async_run_with_timeout(self.wait_for_rcv(topic, msg, msg_key='data'), timeout=10)
        self.assertTrue(self.is_msg_received(topic, msg, msg_key='data'))

    @patch("hummingbot.client.command.balance_command.BalanceCommand.balance")
    def test_mqtt_command_balance_paper_failure(
            self,
            balance_mock: MagicMock
    ):
        balance_mock.side_effect = self._create_exception_and_unlock_test_with_event
        self.start_mqtt()

        msg = {
            'exchange': 'binance',
            'asset': 'BTC-USD',
            'amount': '1.0',
        }

        self.fake_mqtt_broker.publish_to_subscription(self.get_topic_for(self.BALANCE_PAPER_URI), msg)

        topic = f"test_reply/hbot/{self.instance_id}/balance/paper"
        msg = {'status': 400, 'msg': self.fake_err_msg, 'data': ''}
        self.async_run_with_timeout(self.wait_for_rcv(topic, msg, msg_key='data'), timeout=10)
        self.assertTrue(self.is_msg_received(topic, msg, msg_key='data'))

    @patch("hummingbot.client.command.config_command.ConfigCommand.config")
    def test_mqtt_command_config_updates_configurable_keys(
            self,
            config_mock: MagicMock
    ):
        config_mock.side_effect = self._create_exception_and_unlock_test_with_event
        self.start_mqtt()

        config_msg = {
            'params': [
                ('skata', 90),
            ]
        }

        self.fake_mqtt_broker.publish_to_subscription(
            self.get_topic_for(self.CONFIG_URI),
            config_msg
        )
        topic = f"test_reply/hbot/{self.instance_id}/config"
        msg = {'changes': [], 'config': {}, 'status': 400, 'msg': "Invalid param key(s): ['skata']"}
        self.async_run_with_timeout(self.wait_for_rcv(topic, msg, msg_key='data'), timeout=10)
        self.assertTrue(self.is_msg_received(topic, msg, msg_key='data'))

    @patch("hummingbot.client.command.config_command.ConfigCommand.config")
    def test_mqtt_command_config_failure(
            self,
            config_mock: MagicMock
    ):
        config_mock.side_effect = self._create_exception_and_unlock_test_with_event
        self.start_mqtt()

        self.fake_mqtt_broker.publish_to_subscription(self.get_topic_for(self.CONFIG_URI), {})

        topic = f"test_reply/hbot/{self.instance_id}/config"
        msg = {'changes': [], 'config': {}, 'status': 400, 'msg': self.fake_err_msg}
        self.async_run_with_timeout(self.wait_for_rcv(topic, msg, msg_key='data'), timeout=10)
        self.assertTrue(self.is_msg_received(topic, msg, msg_key='data'))

    @patch("hummingbot.client.command.history_command.HistoryCommand.history")
    def test_mqtt_command_history_failure(
            self,
            history_mock: MagicMock
    ):
        history_mock.side_effect = self._create_exception_and_unlock_test_with_event
        self.start_mqtt()

        self.fake_mqtt_broker.publish_to_subscription(self.get_topic_for(self.HISTORY_URI), {})

        topic = f"test_reply/hbot/{self.instance_id}/history"
        msg = {'status': 400, 'msg': self.fake_err_msg, 'trades': []}
        self.async_run_with_timeout(self.wait_for_rcv(topic, msg, msg_key='data'), timeout=10)
        self.assertTrue(self.is_msg_received(topic, msg, msg_key='data'))

    @patch("hummingbot.client.command.import_command.load_strategy_config_map_from_file")
    @patch("hummingbot.client.command.status_command.StatusCommand.status_check_all")
    @patch("hummingbot.client.command.import_command.ImportCommand.import_config_file", new_callable=AsyncMock)
    def test_mqtt_command_import_failure(
            self,
            import_mock: AsyncMock,
            status_check_all_mock: MagicMock,
            load_strategy_config_map_from_file: MagicMock
    ):
        import_mock.side_effect = self._create_exception_and_unlock_test_with_event_async
        self.start_mqtt()
        self.send_fake_import_cmd(status_check_all_mock=status_check_all_mock,
                                  load_strategy_config_map_from_file=load_strategy_config_map_from_file,
                                  invalid_strategy=False)

        topic = f"test_reply/hbot/{self.instance_id}/import"
        msg = {'status': 400, 'msg': 'Some error'}
        self.async_run_with_timeout(self.wait_for_rcv(topic, msg, msg_key='data'), timeout=10)
        self.assertTrue(self.is_msg_received(topic, msg, msg_key='data'))

    @patch("hummingbot.client.command.import_command.load_strategy_config_map_from_file")
    @patch("hummingbot.client.command.status_command.StatusCommand.status_check_all")
    @patch("hummingbot.client.command.import_command.ImportCommand.import_config_file", new_callable=AsyncMock)
    def test_mqtt_command_import_empty_strategy(
            self,
            import_mock: AsyncMock,
            status_check_all_mock: MagicMock,
            load_strategy_config_map_from_file: MagicMock
    ):
        import_mock.side_effect = self._create_exception_and_unlock_test_with_event_async
        topic = f"test_reply/hbot/{self.instance_id}/import"
        msg = {'status': 400, 'msg': 'Empty strategy_name given!'}
        self.start_mqtt()
        self.send_fake_import_cmd(status_check_all_mock=status_check_all_mock,
                                  load_strategy_config_map_from_file=load_strategy_config_map_from_file,
                                  invalid_strategy=False,
                                  empty_name=True)
        self.async_run_with_timeout(self.wait_for_rcv(topic, msg, msg_key='data'), timeout=10)
        self.assertTrue(self.is_msg_received(topic, msg, msg_key='data'))

    @patch("hummingbot.client.command.status_command.StatusCommand.strategy_status", new_callable=AsyncMock)
    def test_mqtt_command_status_no_strategy_running(
            self,
            strategy_status_mock: AsyncMock
    ):
        strategy_status_mock.side_effect = self._create_exception_and_unlock_test_with_event_async
        self.start_mqtt()
        self.fake_mqtt_broker.publish_to_subscription(
            self.get_topic_for(self.STATUS_URI),
            {'async_backend': 0}
        )
        topic = f"test_reply/hbot/{self.instance_id}/status"
        msg = {'status': 400, 'msg': 'No strategy is currently running!', 'data': ''}
        self.async_run_with_timeout(self.wait_for_rcv(topic, msg, msg_key='data'), timeout=10)
        self.assertTrue(self.is_msg_received(topic, msg, msg_key='data'))

    @patch("hummingbot.client.command.status_command.StatusCommand.strategy_status", new_callable=AsyncMock)
    def test_mqtt_command_status_async(
            self,
            strategy_status_mock: AsyncMock
    ):
        strategy_status_mock.side_effect = self._create_exception_and_unlock_test_with_event_async
        self.hbapp.strategy = {}
        self.start_mqtt()
        self.fake_mqtt_broker.publish_to_subscription(
            self.get_topic_for(self.STATUS_URI),
            {'async_backend': 1}
        )
        topic = f"test_reply/hbot/{self.instance_id}/status"
        msg = {'status': 200, 'msg': '', 'data': ''}
        self.async_run_with_timeout(self.wait_for_rcv(topic, msg, msg_key='data'), timeout=10)
        self.assertTrue(self.is_msg_received(topic, msg, msg_key='data'))
        self.hbapp.strategy = None

    @patch("hummingbot.client.command.status_command.StatusCommand.strategy_status", new_callable=AsyncMock)
    def test_mqtt_command_status_sync(
            self,
            strategy_status_mock: AsyncMock
    ):
        strategy_status_mock.side_effect = self._create_exception_and_unlock_test_with_event_async
        self.hbapp.strategy = {}
        self.start_mqtt()
        self.fake_mqtt_broker.publish_to_subscription(
            self.get_topic_for(self.STATUS_URI),
            {'async_backend': 0}
        )
        topic = f"test_reply/hbot/{self.instance_id}/status"
        msg = {'status': 400, 'msg': 'Some error', 'data': ''}
        self.async_run_with_timeout(self.wait_for_rcv(topic, msg, msg_key='data'), timeout=10)
        self.assertTrue(self.is_msg_received(topic, msg, msg_key='data'))
        self.hbapp.strategy = None

    @patch("hummingbot.client.command.status_command.StatusCommand.strategy_status", new_callable=AsyncMock)
    def test_mqtt_command_status_failure(
            self,
            strategy_status_mock: AsyncMock
    ):
        strategy_status_mock.side_effect = self._create_exception_and_unlock_test_with_event_async
        self.start_mqtt()
        self.fake_mqtt_broker.publish_to_subscription(self.get_topic_for(self.STATUS_URI), {})
        topic = f"test_reply/hbot/{self.instance_id}/status"
        msg = {'status': 400, 'msg': 'No strategy is currently running!', 'data': ''}
        self.async_run_with_timeout(self.wait_for_rcv(topic, msg, msg_key='data'), timeout=10)
        self.assertTrue(self.is_msg_received(topic, msg, msg_key='data'))

    @patch("hummingbot.client.command.stop_command.StopCommand.stop")
    def test_mqtt_command_stop_failure(
            self,
            stop_mock: MagicMock
    ):
        stop_mock.side_effect = self._create_exception_and_unlock_test_with_event
        self.start_mqtt()

        self.fake_mqtt_broker.publish_to_subscription(self.get_topic_for(self.STOP_URI), {})

        topic = f"test_reply/hbot/{self.instance_id}/stop"
        msg = {'status': 400, 'msg': self.fake_err_msg}
        self.async_run_with_timeout(self.wait_for_rcv(topic, msg, msg_key='data'), timeout=10)
        self.assertTrue(self.is_msg_received(topic, msg, msg_key='data'))

    def test_mqtt_rpc_response_envelope_is_wire_compatible(self):
        # A failing balance command exercises the full request -> handler ->
        # reply_to round-trip; assert the response envelope matches commlib.
        with patch("hummingbot.client.command.balance_command.BalanceCommand.balance") as balance_mock:
            balance_mock.side_effect = self._create_exception_and_unlock_test_with_event
            self.start_mqtt()
            self.fake_mqtt_broker.publish_to_subscription(
                self.get_topic_for(self.BALANCE_PAPER_URI),
                {'exchange': 'binance', 'asset': 'BTC-USD', 'amount': '1.0'})
            topic = f"test_reply/hbot/{self.instance_id}/balance/paper"
            expected = {'status': 400, 'msg': self.fake_err_msg, 'data': ''}
            self.async_run_with_timeout(self.wait_for_rcv(topic, expected, msg_key='data'), timeout=10)

        envelope = self.fake_mqtt_broker.received_msgs[topic][0]
        self.assertIn('header', envelope)
        self.assertIn('data', envelope)
        header = envelope['header']
        self.assertEqual('', header['reply_to'])
        self.assertEqual('json', header['content_type'])
        self.assertEqual('utf8', header['encoding'])
        self.assertEqual('commlib', header['agent'])
        self.assertIsInstance(header['timestamp'], int)
        self.assertEqual(expected, envelope['data'])

    def test_mqtt_event_buy_order_created(self):
        self.start_mqtt()

        order = LimitOrder(client_order_id="HBOT_1",
                           trading_pair="HBOT-USDT",
                           is_buy=True,
                           base_currency="HBOT",
                           quote_currency="USDT",
                           price=Decimal("100"),
                           quantity=Decimal("1.5")
                           )

        self.emit_order_created_event(self.test_market, order)

        events_topic = f"hbot/{self.instance_id}/events"

        evt_type = "BuyOrderCreated"
        self.async_run_with_timeout(self.wait_for_rcv(events_topic, evt_type, msg_key='type'), timeout=10)
        self.assertTrue(self.is_msg_received(events_topic, evt_type, msg_key='type'))

    def test_mqtt_event_sell_order_created(self):
        self.start_mqtt()

        order = LimitOrder(client_order_id="HBOT_1",
                           trading_pair="HBOT-USDT",
                           is_buy=False,
                           base_currency="HBOT",
                           quote_currency="USDT",
                           price=Decimal("100"),
                           quantity=Decimal("1.5")
                           )

        self.emit_order_created_event(self.test_market, order)

        events_topic = f"hbot/{self.instance_id}/events"

        evt_type = "SellOrderCreated"
        self.async_run_with_timeout(self.wait_for_rcv(events_topic, evt_type, msg_key='type'), timeout=10)
        self.assertTrue(self.is_msg_received(events_topic, evt_type, msg_key='type'))

    def test_mqtt_event_order_expired(self):
        self.start_mqtt()

        self.emit_order_expired_event(self.test_market)

        events_topic = f"hbot/{self.instance_id}/events"

        evt_type = "OrderExpired"
        self.async_run_with_timeout(self.wait_for_rcv(events_topic, evt_type, msg_key='type'), timeout=10)
        self.assertTrue(self.is_msg_received(events_topic, evt_type, msg_key='type'))

    def test_mqtt_subscribed_topics(self):
        self.start_mqtt()
        self.assertTrue(self.gateway is not None)
        expected_topics = sorted(list([f"hbot/{self.instance_id}/{topic}"
                                       for topic in (self.command_topics + ['external/event/#'])]))
        self.async_run_with_timeout(self.wait_for_subscriptions(len(expected_topics)), timeout=10)
        self.assertEqual(expected_topics, sorted(list(self.fake_mqtt_broker.subscriptions.keys())))

    def test_mqtt_heartbeat_published(self):
        self.start_mqtt()
        hb_topic = f"hbot/{self.instance_id}/hb"
        self.async_run_with_timeout(self.wait_for_rcv(hb_topic), timeout=10)
        self.assertTrue(self.is_msg_received(hb_topic))
        self.assertIn('ts', self.fake_mqtt_broker.received_msgs[hb_topic][0])

    def test_mqtt_online_status_update(self):
        self.start_mqtt()
        status_topic = f"hbot/{self.instance_id}/status_updates"
        self.async_run_with_timeout(self.wait_for_rcv(status_topic, 'online'), timeout=10)
        self.assertTrue(self.is_msg_received(status_topic, 'online'))

    def test_mqtt_reconnects_on_mqtt_error(self):
        self.start_mqtt()
        self.async_run_with_timeout(self.wait_for_connected(), timeout=10)
        self.assertTrue(self.gateway.health)
        # Force the broker connection to drop.
        self.fake_mqtt_broker.inject_disconnect()
        self.async_run_with_timeout(
            self.wait_for_logged(
                "WARNING",
                "MQTT bridge disconnected: Simulated broker disconnect. Reconnecting in 0.0s."),
            timeout=10)
        # The single reconnect loop brings it back online by itself.
        self.async_run_with_timeout(self.wait_for_connected(), timeout=10)
        self.assertTrue(self.gateway.health)

    def test_mqtt_publish_from_non_main_thread(self):
        self.start_mqtt()
        self.async_run_with_timeout(self.wait_for_connected(), timeout=10)
        topic = f"hbot/{self.instance_id}/threadtest"

        def worker():
            self.gateway.publish(topic, {"msg": "fromthread"}, 0)

        t = threading.Thread(target=worker)
        t.start()
        t.join()

        self.async_run_with_timeout(self.wait_for_rcv(topic, "fromthread"), timeout=10)
        self.assertTrue(self.is_msg_received(topic, "fromthread"))

    @patch("hummingbot.remote_iface.mqtt.mqtts_logger", None)
    def test_mqtt_eventforwarder_logger(self):
        self.assertTrue(MQTTMarketEventForwarder.logger() is not None)
        self.start_mqtt()

    def test_mqtt_eventforwarder_unknown_events(self):
        self.start_mqtt()
        test_evt = {"unknown": "you don't know me"}
        self.gateway._market_events._send_mqtt_event(event_tag=999,
                                                     pubsub=None,
                                                     event=test_evt)

        events_topic = f"hbot/{self.instance_id}/events"

        evt_type = "Unknown"
        self.async_run_with_timeout(self.wait_for_rcv(events_topic, evt_type, msg_key='type'), timeout=10)
        self.assertTrue(self.is_msg_received(events_topic, evt_type, msg_key='type'))
        self.assertTrue(self.is_msg_received(events_topic, test_evt, msg_key='data'))

    def test_mqtt_eventforwarder_invalid_events(self):
        self.start_mqtt()
        self.gateway._market_events._send_mqtt_event(event_tag=999,
                                                     pubsub=None,
                                                     event="i feel empty")

        events_topic = f"hbot/{self.instance_id}/events"

        evt_type = "Unknown"
        self.async_run_with_timeout(
            self.wait_for_rcv(events_topic, evt_type, msg_key='type'), timeout=10)
        self.assertTrue(self.is_msg_received(events_topic, evt_type, msg_key='type'))
        self.assertTrue(self.is_msg_received(events_topic, {}, msg_key='data'))

    def test_mqtt_notifier_fakes(self):
        self.start_mqtt()
        self.assertEqual(self.gateway._notifier.start(), None)
        self.assertEqual(self.gateway._notifier.stop(), None)

    def test_mqtt_gateway_stop(self):
        self.start_mqtt()
        self.async_run_with_timeout(self.wait_for_connected(), timeout=10)
        self.assertTrue(self.gateway.health)
        self.gateway.stop()
        self.assertFalse(self.gateway.health)

    def test_eevent_queue_factory(self):
        self.start_mqtt()
        from hummingbot.remote_iface.mqtt import EEventQueueFactory, ExternalEventFactory
        queue = ExternalEventFactory.create_queue('test')
        self.assertTrue(queue is not None)

        from collections import deque
        dq = deque()
        EEventQueueFactory._on_event(dq, {'a': 1}, 'testevent')
        self.assertTrue(1)

    def test_eevent_listener_factory(self):
        self.start_mqtt()
        from hummingbot.remote_iface.mqtt import ExternalEventFactory

        def clb(msg, event_name):
            pass

        ExternalEventFactory.create_async('test.a.b', clb)
        ExternalEventFactory.remove_listener('test.a.b', clb)
        try:
            MQTTGateway._instance = None
            ExternalEventFactory.create_async('test.a.b', clb)
            ExternalEventFactory.remove_listener('test.a.b', clb)
        except Exception:
            self.assertTrue(1)
        else:
            self.assertTrue(0)

    def test_etopic_queue_factory(self):
        self.start_mqtt()
        from hummingbot.remote_iface.mqtt import ETopicQueueFactory, ExternalTopicFactory
        queue = ExternalTopicFactory.create_queue('test/a/b')
        self.assertTrue(queue is not None)

        from collections import deque
        dq = deque()
        ETopicQueueFactory._on_message(dq, {'a': 1}, 'test/external')
        self.assertTrue(1)

    def test_etopic_listener_factory(self):
        self.start_mqtt()
        from hummingbot.remote_iface.mqtt import ExternalTopicFactory

        def clb(msg, topic):
            pass

        listener = ExternalTopicFactory.create_async('test/a/b', clb)
        self.assertTrue(listener is not None)
        ExternalTopicFactory.remove_listener(listener)

    def test_external_events_add_remove(self):
        self.start_mqtt()
        from hummingbot.remote_iface.mqtt import MQTTGateway

        def clb(msg, event_name):
            pass

        gw = MQTTGateway.main()
        self.assertTrue(len(gw._external_events._listeners.get('*')) == 0)
        gw.add_external_event_listener('*', clb)
        self.assertTrue(len(gw._external_events._listeners.get('*')) == 1)
        gw.remove_external_event_listener('*', clb)
        self.assertTrue(len(gw._external_events._listeners.get('*')) == 0)
        gw.add_external_event_listener('test.a.b', clb)
        self.assertTrue(len(gw._external_events._listeners.get('test.a.b')) == 1)
        gw.remove_external_event_listener('test.a.b', clb)
        self.assertTrue(len(gw._external_events._listeners.get('test.a.b')) == 0)

    def test_mqtt_log_handler(self):
        import logging

        from hummingbot.logger import HummingbotLogger
        from hummingbot.remote_iface.mqtt import MQTTLogHandler
        self.start_mqtt()

        handler = MQTTLogHandler(self.hbapp, self.gateway)
        handler.emit(logging.LogRecord('', 1, '', '', '', '', ''))
        self.assertTrue(1)

        logger = HummingbotLogger('testlogger')
        self.gateway.add_log_handler(logger)
        self.gateway.remove_log_handler(logger)
        logger = self.gateway._get_root_logger()
        self.assertTrue(logger is not None)
        self.gateway._remove_log_handlers()

    def test_market_events(self):
        self.start_mqtt()
        from hummingbot.core.data_type.trade_fee import AddedToCostTradeFee, DeductedFromReturnsTradeFee
        from hummingbot.remote_iface.mqtt import MQTTGateway

        gw = MQTTGateway.main()
        gw._market_events._make_event_payload({
            'a': 'a',
            'b': 1,
            'c': Decimal('1.0'),
            'd': DeductedFromReturnsTradeFee(),
            'e': AddedToCostTradeFee(),
            'f': {'a': 1},
            'g': [Decimal('2.0'), {'h': Decimal('3.0')}],
            'type': 'TEST',
            'order_type': 'BUY',
            'trade_type': 'LIMIT',
        })
        self.assertTrue(1)

    def test_etopic_listener_class(self):
        from hummingbot.remote_iface.mqtt import ETopicListener

        def clb(msg, topic):
            pass

        self.start_mqtt()
        listener = ETopicListener('test', clb, use_bot_prefix=True)
        self.assertTrue(listener is not None)
        listener.stop()
        listener = ETopicListener('test', clb, use_bot_prefix=False)
        self.assertTrue(listener is not None)
        listener.stop()

        prev_gw = MQTTGateway.main()
        MQTTGateway._instance = None
        try:
            listener = ETopicListener('test', clb, use_bot_prefix=False)
        except Exception:
            self.assertTrue(1)
        else:
            self.assertFalse(1)
        MQTTGateway._instance = prev_gw

    def test_eevent_queue_factory_class(self):
        from hummingbot.remote_iface.mqtt import EEventQueueFactory
        self.start_mqtt()

        equeue = EEventQueueFactory.create(event_name='test', queue_size=2)
        self.assertTrue(equeue is not None)

        prev_gw = MQTTGateway.main()
        MQTTGateway._instance = None
        try:
            equeue = EEventQueueFactory.create(event_name='test', queue_size=2)
        except Exception:
            self.assertTrue(1)
        else:
            self.assertFalse(1)
        MQTTGateway._instance = prev_gw

    def test_eevent_listener_factory_class(self):
        from hummingbot.remote_iface.mqtt import EEventListenerFactory
        self.start_mqtt()

        def clb(msg, topic):
            pass

        EEventListenerFactory.create(event_name='test', callback=clb)
        prev_gw = MQTTGateway.main()
        MQTTGateway._instance = None
        try:
            EEventListenerFactory.create(event_name='test',
                                         callback=clb)
        except Exception:
            self.assertTrue(1)
        else:
            self.assertFalse(1)
        try:
            EEventListenerFactory.remove(event_name='test',
                                         callback=clb)
        except Exception:
            self.assertTrue(1)
        else:
            self.assertFalse(1)
        MQTTGateway._instance = prev_gw

    def test_mqtt_external_events_class(self):
        from hummingbot.remote_iface.messages import ExternalEventMessage
        from hummingbot.remote_iface.mqtt import MQTTExternalEvents

        self.start_mqtt()

        def clb(msg, topic):
            pass

        eevents = MQTTExternalEvents(self.hbapp, self.gateway)
        eevents.add_global_listener(clb)
        ename = eevents._event_uri_to_name('hbot/bot1/external/event/e1')
        self.assertTrue(ename == "e1")
        eevents.add_listener('e1', clb)
        eevents.add_listener('e1', clb)
        eevents._on_event_arrived(ExternalEventMessage(),
                                  'hbot/bot1/external/event/e1')
        self.assertTrue(len(eevents._listeners) == 2)
        self.assertTrue('*' in eevents._listeners)
        self.assertTrue('e1' in eevents._listeners)
        self.assertTrue(ename in eevents._listeners)

        eevents._listeners = {}
        eevents.add_global_listener(clb)
        eevents.remove_global_listener(clb)
        eevents.add_listener('test_event', clb)
        eevents.remove_listener('test_event', clb)
        eevents.add_listener('test_event', clb)
        eevents.add_listener('test_event', clb)
        eevents.remove_listener('test_event', clb)

    def test_mqtt_external_event_delivery_wraps_message(self):
        from hummingbot.remote_iface.mqtt import ExternalEventFactory
        self.start_mqtt()
        self.async_run_with_timeout(self.wait_for_connected(), timeout=10)

        received = []

        def clb(msg, name):
            received.append((name, msg))

        ExternalEventFactory.create_async('*', clb)
        event_topic = f"hbot/{self.instance_id}/external/event/order/market"
        self.fake_mqtt_broker.publish_event(
            event_topic, {'type': 'eevent', 'data': {'type': 'buy', 'amount': '1'}})

        async def _wait():
            async with timeout(3):
                while not received:
                    await asyncio.sleep(0.05)
        self.async_run_with_timeout(_wait(), timeout=10)
        name, msg = received[0]
        self.assertEqual('order.market', name)
        # Listeners must receive an ExternalEventMessage object with `.data`.
        self.assertEqual({'type': 'buy', 'amount': '1'}, msg.data)

    def test_mqtt_gateway_health(self):
        health = self.gateway.health
        self.assertFalse(health)

    def test_mqtt_gateway_namespace_wrong_lastchar(self):
        prev_ns = self.gateway._hb_app.client_config_map.mqtt_bridge.mqtt_namespace
        self.gateway._hb_app.client_config_map.mqtt_bridge.mqtt_namespace = 'test/'
        gw = MQTTGateway(self.hbapp)
        self.assertTrue(gw.namespace == 'test')
        gw.stop()
        del gw
        self.gateway._hb_app.client_config_map.mqtt_bridge.mqtt_namespace = prev_ns

    def test_etopic_publisher(self):
        self.start_mqtt()
        from hummingbot.remote_iface.mqtt import EMTopicPublisher, ETopicPublisher
        test_msg = {
            "a": "test",
            "b": 1,
            "c": False,
            "d": {},
            "e": []
        }
        pub = ETopicPublisher('test/a/b', use_bot_prefix=False)
        pub.send(test_msg)
        self.async_run_with_timeout(self.wait_for_rcv('test/a/b'), timeout=10)
        self.assertTrue(self.is_msg_received('test/a/b'))
        pub2 = EMTopicPublisher(use_bot_prefix=False)
        pub2.send("test/c/d", test_msg)
        self.async_run_with_timeout(self.wait_for_rcv('test/c/d'), timeout=10)
        self.assertTrue(self.is_msg_received('test/c/d'))
