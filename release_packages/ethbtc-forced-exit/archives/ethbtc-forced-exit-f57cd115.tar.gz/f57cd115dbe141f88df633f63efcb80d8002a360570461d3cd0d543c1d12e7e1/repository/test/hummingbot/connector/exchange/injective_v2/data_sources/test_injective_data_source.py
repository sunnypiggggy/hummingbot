import asyncio
import re
from decimal import Decimal
from test.hummingbot.connector.exchange.injective_v2.programmable_query_executor import ProgrammableQueryExecutor
from typing import Awaitable, Optional, Union
from unittest import TestCase
from unittest.mock import patch

from pyinjective.composer_v2 import Composer
from pyinjective.core.market_v2 import SpotMarket
from pyinjective.core.network import Network
from pyinjective.core.token import Token
from pyinjective.wallet import Address, PrivateKey

from hummingbot.connector.exchange.injective_v2 import injective_constants as CONSTANTS
from hummingbot.connector.exchange.injective_v2.data_sources.injective_grantee_data_source import (
    InjectiveGranteeDataSource,
)
from hummingbot.connector.exchange.injective_v2.data_sources.injective_read_only_data_source import (
    InjectiveReadOnlyDataSource,
)
from hummingbot.connector.exchange.injective_v2.injective_market import InjectiveSpotMarket
from hummingbot.connector.exchange.injective_v2.injective_v2_utils import (
    InjectiveMessageBasedTransactionFeeCalculatorMode,
)
from hummingbot.connector.gateway.gateway_in_flight_order import GatewayInFlightOrder
from hummingbot.core.data_type.common import OrderType, TradeType


class InjectiveGranteeDataSourceTests(TestCase):
    # the level is required to receive logs from the data source logger
    level = 0
    usdt_usdc_market_id = "0x8b1a4d3e8f6b559e30e40922ee3662dd78edf7042330d4d620d188699d1a9715"  # noqa: mock
    inj_usdt_market_id = "0x0611780ba69656949525013d947713300f56c37b6175e02f26bffa495c3208fe"  # noqa: mock

    @patch("hummingbot.core.utils.trading_pair_fetcher.TradingPairFetcher.fetch_all")
    def setUp(self, _) -> None:
        self._initialize_timeout_height_sync_task = patch(
            "hummingbot.connector.exchange.injective_v2.data_sources.injective_grantee_data_source"
            ".AsyncClient._initialize_timeout_height_sync_task"
        )
        self._initialize_timeout_height_sync_task.start()
        super().setUp()
        self._original_async_loop = asyncio.get_event_loop()
        self.async_loop = asyncio.new_event_loop()
        self.async_tasks = []
        asyncio.set_event_loop(self.async_loop)

        _, grantee_private_key = PrivateKey.generate()
        _, granter_private_key = PrivateKey.generate()

        self.data_source = InjectiveGranteeDataSource(
            private_key=grantee_private_key.to_hex(),
            subaccount_index=0,
            granter_address=Address(bytes.fromhex(granter_private_key.to_public_key().to_hex())).to_acc_bech32(),
            granter_subaccount_index=0,
            network=Network.testnet(node="sentry"),
            rate_limits=CONSTANTS.PUBLIC_NODE_RATE_LIMITS,
            fee_calculator_mode=InjectiveMessageBasedTransactionFeeCalculatorMode(),
        )

        self.data_source._is_trading_account_initialized = True
        self.data_source._is_timeout_height_initialized = True
        self.data_source._client.timeout_height = 0
        self.query_executor = ProgrammableQueryExecutor()
        self.data_source._query_executor = self.query_executor

        self.data_source._composer = Composer(network=self.data_source.network_name)

        self.log_records = []
        self._logs_event: Optional[asyncio.Event] = None
        self.data_source.logger().setLevel(1)
        self.data_source.logger().addHandler(self)

    def tearDown(self) -> None:
        self.async_run_with_timeout(self.data_source.stop())
        for task in self.async_tasks:
            task.cancel()
        self.async_loop.stop()
        # self.async_loop.close()
        # Since the event loop will change we need to remove the logs event created in the old event loop
        self._logs_event = None
        asyncio.set_event_loop(self._original_async_loop)
        self._initialize_timeout_height_sync_task.stop()
        super().tearDown()

    def async_run_with_timeout(self, coroutine: Awaitable, timeout: float = 1):
        ret = self.async_loop.run_until_complete(asyncio.wait_for(coroutine, timeout))
        return ret

    def create_task(self, coroutine: Awaitable) -> asyncio.Task:
        task = self.async_loop.create_task(coroutine)
        self.async_tasks.append(task)
        return task

    def handle(self, record):
        self.log_records.append(record)
        if self._logs_event is not None:
            self._logs_event.set()

    def is_logged(self, log_level: str, message: Union[str, re.Pattern]) -> bool:
        expression = (
            re.compile(
                f"^{message}$"
                .replace(".", r"\.")
                .replace("?", r"\?")
                .replace("/", r"\/")
                .replace("(", r"\(")
                .replace(")", r"\)")
                .replace("[", r"\[")
                .replace("]", r"\]")
            )
            if isinstance(message, str)
            else message
        )
        return any(
            record.levelname == log_level and expression.match(record.getMessage()) is not None
            for record in self.log_records
        )

    def test_market_and_tokens_construction(self):
        spot_markets_response = self._spot_markets_response()
        self.query_executor._spot_markets_responses.put_nowait(spot_markets_response)
        self.query_executor._derivative_markets_responses.put_nowait({})
        tokens = dict()
        for market in spot_markets_response.values():
            tokens[market.base_token.denom] = market.base_token
            tokens[market.quote_token.denom] = market.quote_token
        self.query_executor._tokens_responses.put_nowait(
            {token.symbol: token for token in tokens.values()}
        )

        market_info = self._inj_usdt_market_info()
        inj_usdt_market: InjectiveSpotMarket = self.async_run_with_timeout(
            self.data_source.spot_market_info_for_id(market_info.id)
        )
        inj_token = inj_usdt_market.base_token
        usdt_token = inj_usdt_market.quote_token

        self.assertEqual(market_info.id, inj_usdt_market.market_id)
        self.assertEqual(market_info, inj_usdt_market.native_market)
        self.assertEqual(f"{inj_token.unique_symbol}-{usdt_token.unique_symbol}", inj_usdt_market.trading_pair())
        self.assertEqual(market_info.base_token.denom, inj_token.denom)
        self.assertEqual(market_info.base_token.symbol, inj_token.symbol)
        self.assertEqual(inj_token.symbol, inj_token.unique_symbol)
        self.assertEqual(market_info.base_token.name, inj_token.name)
        self.assertEqual(market_info.base_token.decimals, inj_token.decimals)
        self.assertEqual(market_info.quote_token.denom, usdt_token.denom)
        self.assertEqual(market_info.quote_token.symbol, usdt_token.symbol)
        self.assertEqual(usdt_token.symbol, usdt_token.unique_symbol)
        self.assertEqual(market_info.quote_token.name, usdt_token.name)
        self.assertEqual(market_info.quote_token.decimals, usdt_token.decimals)

    def test_create_orders_fails_if_tx_broadcast_fails(self):
        spot_markets_response = self._spot_markets_response()
        self.query_executor._spot_markets_responses.put_nowait(spot_markets_response)
        self.query_executor._derivative_markets_responses.put_nowait({})
        tokens = dict()
        for market in spot_markets_response.values():
            tokens[market.base_token.denom] = market.base_token
            tokens[market.quote_token.denom] = market.quote_token
        self.query_executor._tokens_responses.put_nowait(
            {token.symbol: token for token in tokens.values()}
        )

        tx_failure_response = {
            "txhash": "017C130E3602A48E5C9D661CAC657BF1B79262D4B71D5C25B1DA62DE2338DA0E",  # noqa: mock
            "rawLog": "[]",
            "code": 20,
        }
        self.query_executor._send_transaction_responses.put_nowait(tx_failure_response)

        order = GatewayInFlightOrder(
            client_order_id="someOrderIDCreate",
            trading_pair="INJ-USDT",
            order_type=OrderType.LIMIT,
            trade_type=TradeType.BUY,
            creation_timestamp=123123123,
            amount=Decimal("10"),
            price=Decimal("100"),
        )

        results = self.async_run_with_timeout(self.data_source.create_orders(spot_orders=[order]))

        self.assertEqual(1, len(results))
        self.assertEqual(order.client_order_id, results[0].client_order_id)
        self.assertIsInstance(results[0].exception, ValueError)
        expected_error_message = (
            f"Error sending the order creation transaction. Code: {tx_failure_response['code']}. "
            f"TXHash: {tx_failure_response['txhash']}. TXLog: {tx_failure_response['rawLog']}")
        self.assertEqual(expected_error_message, str(results[0].exception))

    def test_cancel_orders_fails_if_tx_broadcast_fails(self):
        spot_markets_response = self._spot_markets_response()
        self.query_executor._spot_markets_responses.put_nowait(spot_markets_response)
        self.query_executor._derivative_markets_responses.put_nowait({})
        tokens = dict()
        for market in spot_markets_response.values():
            tokens[market.base_token.denom] = market.base_token
            tokens[market.quote_token.denom] = market.quote_token
        self.query_executor._tokens_responses.put_nowait(
            {token.symbol: token for token in tokens.values()}
        )

        tx_failure_response = {
            "txhash": "017C130E3602A48E5C9D661CAC657BF1B79262D4B71D5C25B1DA62DE2338DA0E",  # noqa: mock
            "rawLog": "[]",
            "code": 20,
        }
        self.query_executor._send_transaction_responses.put_nowait(tx_failure_response)

        order = GatewayInFlightOrder(
            client_order_id="someOrderIDCreate",
            trading_pair="INJ-USDT",
            order_type=OrderType.LIMIT,
            trade_type=TradeType.BUY,
            creation_timestamp=123123123,
            amount=Decimal("10"),
            price=Decimal("100"),
        )

        results = self.async_run_with_timeout(self.data_source.cancel_orders(spot_orders=[order]))

        self.assertEqual(1, len(results))
        self.assertEqual(order.client_order_id, results[0].client_order_id)
        self.assertIsInstance(results[0].exception, ValueError)
        expected_error_message = (
            f"Error sending the order cancel transaction. Code: {tx_failure_response['code']}. "
            f"TXHash: {tx_failure_response['txhash']}. TXLog: {tx_failure_response['rawLog']}")
        self.assertEqual(expected_error_message, str(results[0].exception))

    def test_cancel_all_subaccount_orders_fails_if_tx_broadcast_fails(self):
        spot_markets_response = self._spot_markets_response()
        self.query_executor._spot_markets_responses.put_nowait(spot_markets_response)
        self.query_executor._derivative_markets_responses.put_nowait({})
        tokens = dict()
        for market in spot_markets_response.values():
            tokens[market.base_token.denom] = market.base_token
            tokens[market.quote_token.denom] = market.quote_token
        self.query_executor._tokens_responses.put_nowait(
            {token.symbol: token for token in tokens.values()}
        )

        tx_failure_response = {
            "txhash": "017C130E3602A48E5C9D661CAC657BF1B79262D4B71D5C25B1DA62DE2338DA0E",  # noqa: mock
            "rawLog": "[]",
            "code": 20,
        }
        self.query_executor._send_transaction_responses.put_nowait(tx_failure_response)

        with self.assertRaises(ValueError) as context:
            self.async_run_with_timeout(self.data_source.cancel_all_subaccount_orders(
                spot_markets_ids=list(spot_markets_response.keys()),
            ))
        expected_error_message = (
            f"Error sending the order cancel transaction. Code: {tx_failure_response['code']}. "
            f"TXHash: {tx_failure_response['txhash']}. TXLog: {tx_failure_response['rawLog']}")
        self.assertEqual(expected_error_message, context.exception.args[0])

    def _spot_markets_response(self):
        inj_usdt_market = self._inj_usdt_market_info()
        usdt_usdc_market = self._usdt_usdc_market_info()

        return {
            inj_usdt_market.id: inj_usdt_market,
            usdt_usdc_market.id: usdt_usdc_market,
        }

    def _usdt_usdc_market_info(self):
        base_native_token = Token(
            name="Tether",
            symbol="USDT",
            denom="peggy0xdAC17F958D2ee523a2206206994597C13D831ec7",  # noqa: mock
            address="0xdAC17F958D2ee523a2206206994597C13D831ec7",  # noqa: mock
            decimals=6,
            logo="https://static.alchemyapi.io/images/assets/825.png",
            updated=1685371052879,
            unique_symbol="",
        )
        quote_native_token = Token(
            name="USD Coin",
            symbol="USDC",
            denom="peggy0x87aB3B4C8661e07D6372361211B96ed4Dc36B1B5",  # noqa: mock
            address="0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",  # noqa: mock
            decimals=6,
            logo="https://static.alchemyapi.io/images/assets/3408.png",
            updated=1687190809716,
            unique_symbol="",
        )

        native_market = SpotMarket(
            id=self.usdt_usdc_market_id,
            status="active",
            ticker="USDT/USDC",
            base_token=base_native_token,
            quote_token=quote_native_token,
            maker_fee_rate=Decimal("0.001"),
            taker_fee_rate=Decimal("0.002"),
            service_provider_fee=Decimal("0.4"),
            min_price_tick_size=Decimal("0.0001"),
            min_quantity_tick_size=Decimal("0.01"),
            min_notional=Decimal("1"),
        )

        return native_market

    def _inj_usdt_market_info(self):
        base_native_token = Token(
            name="Injective Protocol",
            symbol="INJ",
            denom="inj",
            address="0xe28b3B32B6c345A34Ff64674606124Dd5Aceca30",  # noqa: mock
            decimals=18,
            logo="https://static.alchemyapi.io/images/assets/7226.png",
            updated=1687190809715,
            unique_symbol="",
        )
        quote_native_token = Token(
            name="Tether",
            symbol="USDT",
            denom="peggy0xdAC17F958D2ee523a2206206994597C13D831ec7",  # noqa: mock
            address="0xdAC17F958D2ee523a2206206994597C13D831ec7",  # noqa: mock
            decimals=6,
            logo="https://static.alchemyapi.io/images/assets/825.png",
            updated=1685371052879,
            unique_symbol="",
        )

        native_market = SpotMarket(
            id=self.inj_usdt_market_id,
            status="active",
            ticker="INJ/USDT",
            base_token=base_native_token,
            quote_token=quote_native_token,
            maker_fee_rate=Decimal("-0.0001"),
            taker_fee_rate=Decimal("0.001"),
            service_provider_fee=Decimal("0.4"),
            min_price_tick_size=Decimal("0.0001"),
            min_quantity_tick_size=Decimal("0.001"),
            min_notional=Decimal("1"),
        )

        return native_market


class InjectiveReadOnlyDataSourceTests(TestCase):
    # the level is required to receive logs from the data source logger
    level = 0
    usdt_usdc_market_id = "0x8b1a4d3e8f6b559e30e40922ee3662dd78edf7042330d4d620d188699d1a9715"  # noqa: mock
    inj_usdt_market_id = "0x0611780ba69656949525013d947713300f56c37b6175e02f26bffa495c3208fe"  # noqa: mock

    @patch("hummingbot.core.utils.trading_pair_fetcher.TradingPairFetcher.fetch_all")
    def setUp(self, _) -> None:
        super().setUp()
        self._original_async_loop = asyncio.get_event_loop()
        self.async_loop = asyncio.new_event_loop()
        self.async_tasks = []
        asyncio.set_event_loop(self.async_loop)

        _, grantee_private_key = PrivateKey.generate()
        _, granter_private_key = PrivateKey.generate()

        self.data_source = InjectiveReadOnlyDataSource(
            network=Network.testnet(node="sentry"),
            rate_limits=CONSTANTS.PUBLIC_NODE_RATE_LIMITS,
        )

        self.query_executor = ProgrammableQueryExecutor()
        self.data_source._query_executor = self.query_executor

        self.log_records = []
        self._logs_event: Optional[asyncio.Event] = None
        self.data_source.logger().setLevel(1)
        self.data_source.logger().addHandler(self)

    def tearDown(self) -> None:
        self.async_run_with_timeout(self.data_source.stop())
        for task in self.async_tasks:
            task.cancel()
        self.async_loop.stop()
        # self.async_loop.close()
        # Since the event loop will change we need to remove the logs event created in the old event loop
        self._logs_event = None
        asyncio.set_event_loop(self._original_async_loop)
        super().tearDown()

    def async_run_with_timeout(self, coroutine: Awaitable, timeout: float = 1):
        ret = self.async_loop.run_until_complete(asyncio.wait_for(coroutine, timeout))
        return ret

    def create_task(self, coroutine: Awaitable) -> asyncio.Task:
        task = self.async_loop.create_task(coroutine)
        self.async_tasks.append(task)
        return task

    def handle(self, record):
        self.log_records.append(record)
        if self._logs_event is not None:
            self._logs_event.set()

    def test_order_cancel_message_generation(self):
        self.assertTrue(self.data_source._uses_default_portfolio_subaccount())
