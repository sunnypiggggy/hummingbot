import json
import sys
import tempfile
from unittest.mock import patch
from decimal import Decimal
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "live_guard"))
sys.path.insert(0, str(ROOT / "scripts"))

from account_inventory import (  # noqa: E402
    UnifiedInventoryLedger, ownership_from_documents,
)
from dca_live_guard import Guard  # noqa: E402
import dca_live_guard  # noqa: E402
from risk_recovery import LATCHED  # noqa: E402


def balances(btc="0.003", eth="0.052"):
    return {
        "BTC": {"free": Decimal(btc), "locked": Decimal("0"), "total": Decimal(btc)},
        "ETH": {"free": Decimal(eth), "locked": Decimal("0"), "total": Decimal(eth)},
    }


def seed_ownership(ledger, *, btc="0", eth="0", btc_owner="dca:bot", eth_owner="dca:bot"):
    ledger.reconcile(
        account_fingerprint="test-account", balances=balances("1", "1"),
        ownership={
            "BTC": {btc_owner: btc}, "ETH": {eth_owner: eth},
        },
        evidence_sha256="seed-ownership", open_order_counts={},
        sources_healthy=True, now=1,
    )


def test_ownership_combines_grid_and_dca_evidence_without_account_balance():
    value = ownership_from_documents(
        reservations={"reservations": {"FDUSD": {"base": {
            "BTC": "0.00156", "ETH": "0.052",
        }}}},
        grid_state={"bots": {"grid": {"latest": {"pairs": {
            "BTC-FDUSD": {"net_base": "-0.00156"},
            "ETH-FDUSD": {"net_base": "-0.052"},
        }}}}},
        managed_inventory={"pairs": {
            "BTC-USDT": {"managed_base": "0.0015"},
            "ETH-USDT": {"managed_base": "0.0505"},
        }},
        dca_state={"bots": {
            "dca-live-btcusdt-200": {"latest": {"net_base": "0"}},
            "dca-live-ethusdt-200": {"latest": {"net_base": "0"}},
        }},
    )
    assert value["BTC"]["grid:grid-live-fdusd-400"] == 0
    assert value["ETH"]["grid:grid-live-fdusd-400"] == 0
    assert value["BTC"]["dca:dca-live-btcusdt-200"] == Decimal("0.0015")
    assert value["ETH"]["dca:dca-live-ethusdt-200"] == Decimal("0.0505")


def test_unattributed_requires_three_cycles_and_thirty_seconds():
    with tempfile.TemporaryDirectory() as directory:
        ledger = UnifiedInventoryLedger(Path(directory))
        ownership = {
            "BTC": {"dca:btc": Decimal("0.0015")},
            "ETH": {"dca:eth": Decimal("0.0505")},
        }
        first = ledger.reconcile(
            account_fingerprint="account", balances=balances(), ownership=ownership,
            evidence_sha256="evidence", open_order_counts={}, sources_healthy=True,
            now=100,
        )
        second = ledger.reconcile(
            account_fingerprint="account", balances=balances(), ownership=ownership,
            evidence_sha256="evidence", open_order_counts={}, sources_healthy=True,
            now=115,
        )
        third = ledger.reconcile(
            account_fingerprint="account", balances=balances(), ownership=ownership,
            evidence_sha256="evidence", open_order_counts={}, sources_healthy=True,
            now=131,
        )
        assert first["assets"]["BTC"]["confirmation"]["cycles"] == 1
        assert not second["assets"]["BTC"]["confirmation"]["confirmed"]
        assert third["assets"]["BTC"]["confirmation"]["confirmed"]


def test_dynamic_evidence_does_not_reset_confirmation_but_deficit_is_fail_closed():
    with tempfile.TemporaryDirectory() as directory:
        ledger = UnifiedInventoryLedger(Path(directory))
        owners = {"BTC": {"dca": "0.001"}, "ETH": {"dca": "0.05"}}
        ledger.reconcile(
            account_fingerprint="account", balances=balances(), ownership=owners,
            evidence_sha256="one", open_order_counts={}, sources_healthy=True, now=100,
        )
        reset = ledger.reconcile(
            account_fingerprint="account", balances=balances(), ownership=owners,
            evidence_sha256="two", open_order_counts={}, sources_healthy=True, now=140,
        )
        assert reset["assets"]["BTC"]["confirmation"]["cycles"] == 2
        deficit = ledger.reconcile(
            account_fingerprint="account", balances=balances("0.0005", "0.01"),
            ownership=owners, evidence_sha256="three", open_order_counts={},
            sources_healthy=True, now=180,
        )
        assert not deficit["healthy"]
        assert Decimal(deficit["assets"]["BTC"]["ownership_deficit"]) > 0
        assert deficit["assets"]["BTC"]["confirmation"]["cycles"] == 0


def test_active_orders_do_not_reset_confirmation_but_keep_contract_unhealthy():
    with tempfile.TemporaryDirectory() as directory:
        ledger = UnifiedInventoryLedger(Path(directory))
        owners = {"BTC": {"dca": "0.001"}, "ETH": {"dca": "0.05"}}
        values = []
        for now, evidence in ((100, "one"), (115, "two"), (131, "three")):
            values.append(ledger.reconcile(
                account_fingerprint="account", balances=balances(), ownership=owners,
                evidence_sha256=evidence,
                open_order_counts={"BTC-USDT": 8, "ETH-USDT": 8},
                sources_healthy=True, now=now,
            ))
        btc = values[-1]["assets"]["BTC"]
        assert not values[-1]["healthy"]
        assert values[-1]["active_order_count"] == 16
        assert btc["confirmation_eligible"] is True
        assert btc["confirmation"]["cycles"] == 3
        assert btc["confirmation"]["confirmed"] is True


def test_confirmation_episode_survives_ledger_restart():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        owners = {"BTC": {"dca": "0.001"}, "ETH": {"dca": "0.05"}}
        first = UnifiedInventoryLedger(root).reconcile(
            account_fingerprint="account", balances=balances(), ownership=owners,
            evidence_sha256="one", open_order_counts={"BTC-USDT": 4},
            sources_healthy=True, now=100,
        )
        restarted = UnifiedInventoryLedger(root).reconcile(
            account_fingerprint="account", balances=balances(), ownership=owners,
            evidence_sha256="new-dynamic-evidence", open_order_counts={"BTC-USDT": 4},
            sources_healthy=True, now=115,
        )
        assert restarted["assets"]["BTC"]["episode_id"] == first["assets"]["BTC"]["episode_id"]
        assert restarted["assets"]["BTC"]["confirmation"]["cycles"] == 2


def test_existing_dust_job_migrates_without_reconfirmation():
    with tempfile.TemporaryDirectory() as directory:
        ledger = UnifiedInventoryLedger(Path(directory))
        ledger.start_job(
            job_id="dust", asset="ETH", scope="unattributed_dust",
            pair="ETH-USDT", requested_quantity=Decimal("0.002271579092935063"),
            client_order_id="inv-dust", now=1,
        )
        ledger.finish_job("dust", status="DUST", error="below minimum", now=2)
        value = ledger.reconcile(
            account_fingerprint="account",
            balances=balances("0", "0.0528000000000000000000000001"),
            ownership={"BTC": {}, "ETH": {"dca": "0.050528420907064937"}},
            evidence_sha256="dynamic", open_order_counts={"ETH-USDT": 8},
            sources_healthy=True, now=100,
        )
        eth = value["assets"]["ETH"]
        assert eth["inventory_phase"] == "DUST"
        assert eth["last_notified_transition"] == "INVENTORY_DUST_CLASSIFIED"
        assert eth["confirmation"]["cycles"] == 0
        assert eth["confirmation_block_reason"] == "already_classified_dust"


def test_asset_lease_and_bootstrap_cap_are_persistent():
    with tempfile.TemporaryDirectory() as directory:
        ledger = UnifiedInventoryLedger(Path(directory))
        ledger.set_bootstrap_caps({"BTC": "0.00155"}, now=1)
        assert ledger.bootstrap_cap("BTC") == Decimal("0.00155")
        assert ledger.acquire_lease("BTC", "grid", now=10)
        assert not ledger.acquire_lease("BTC", "dca", now=11)
        ledger.release_lease("BTC", "grid")
        assert ledger.acquire_lease("BTC", "dca", now=12)
        ledger.consume_bootstrap_cap("BTC", now=13)
        assert ledger.bootstrap_cap("BTC") is None


def test_completed_job_requires_persisted_four_part_verification():
    with tempfile.TemporaryDirectory() as directory:
        ledger = UnifiedInventoryLedger(Path(directory))
        job = ledger.start_job(
            job_id="job", asset="BTC", scope="test", pair="BTC-USDT",
            requested_quantity=Decimal("0.001"), client_order_id="inv-job",
        )
        assert not ledger.completed_job_verified(job)
        try:
            ledger.finish_job("job", status="COMPLETED", executed_quantity="0.001")
        except ValueError as exc:
            assert "four-part verification" in str(exc)
        else:
            raise AssertionError("unverified liquidation must not complete")
        verification = {
            "order_verified": True, "balance_verified": True,
            "no_active_orders": True, "requested_quantity_verified": True,
        }
        ledger.finish_job(
            "job", status="COMPLETED", executed_quantity="0.001",
            verification=verification,
        )
        with ledger._connection() as connection:
            completed = dict(connection.execute(
                "SELECT * FROM liquidation_jobs WHERE job_id='job'"
            ).fetchone())
        assert ledger.completed_job_verified(completed)


def test_account_fingerprint_cannot_change_between_guards():
    with tempfile.TemporaryDirectory() as directory:
        ledger = UnifiedInventoryLedger(Path(directory))
        ledger.bind_account("same-account")
        ledger.bind_account("same-account")
        try:
            ledger.bind_account("different-account")
        except RuntimeError as exc:
            assert "fingerprint changed" in str(exc)
        else:
            raise AssertionError("different account must fail closed")


def test_exit_preflight_rejects_shared_deficit_and_owner_overreach():
    with tempfile.TemporaryDirectory() as directory:
        ledger = UnifiedInventoryLedger(Path(directory))
        ledger.reconcile(
            account_fingerprint="account", balances=balances("0.0015", "1"),
            ownership={
                "BTC": {"grid:grid": "0.001", "dca:dca": "0.001"},
                "ETH": {"dca:dca": "0"},
            },
            evidence_sha256="deficit", open_order_counts={},
            sources_healthy=True,
        )
        try:
            ledger.assert_exit_allowed(
                asset="BTC", exchange_total="0.0015",
                owner_key="grid:grid", requested_quantity="0.001",
            )
        except RuntimeError as exc:
            assert "ownership_deficit" in str(exc)
        else:
            raise AssertionError("shared deficit must block every owner exit")

        ledger.reconcile(
            account_fingerprint="account", balances=balances("0.003", "1"),
            ownership={
                "BTC": {"grid:grid": "0.001", "dca:dca": "0.001"},
                "ETH": {"dca:dca": "0"},
            },
            evidence_sha256="healthy", open_order_counts={},
            sources_healthy=True,
        )
        try:
            ledger.assert_exit_allowed(
                asset="BTC", exchange_total="0.003",
                owner_key="grid:grid", requested_quantity="0.0011",
            )
        except RuntimeError as exc:
            assert "exit exceeds" in str(exc)
        else:
            raise AssertionError("a strategy must not sell another owner's inventory")


def test_market_filter_zero_market_step_falls_back_to_lot_size(monkeypatch):
    class Response:
        def raise_for_status(self):
            return None

        def json(self):
            return {"symbols": [{"filters": [
                {"filterType": "MARKET_LOT_SIZE", "stepSize": "0.00000000"},
                {"filterType": "LOT_SIZE", "stepSize": "0.00001000"},
                {"filterType": "MIN_NOTIONAL", "minNotional": "5"},
            ]}]}

    monkeypatch.setattr("dca_live_guard.requests.get", lambda *args, **kwargs: Response())
    step, minimum = Guard._lot_filter("BTC-USDT")
    assert step == Decimal("0.00001000")
    assert minimum == Decimal("5")


def test_third_asset_commission_is_preserved_in_audit_details():
    metrics = Guard._emergency_fill_metrics("BTC-USDT", "SELL", {
        "executedQty": "0.00155", "cummulativeQuoteQty": "101.13",
        "fills": [{
            "commission": "0.00012469", "commissionAsset": "BNB",
            "price": "65247.1",
        }],
    })
    assert metrics["fee_quote"] == "0"
    assert metrics["fee_details"] == [{
        "asset": "BNB", "commission": "0.00012469",
        "fill_price": "65247.1",
    }]


class Exchange:
    def __init__(self, btc="0.003", eth="0"):
        self.orders = []
        self.btc = Decimal(btc)
        self.eth = Decimal(eth)
        self.responses = {}

    def account_balances(self):
        return balances(str(self.btc), str(self.eth))

    def open_orders(self, pair):
        return []

    def cancel_all_orders(self, pair):
        raise AssertionError("no order should need cancellation")

    def market_order(self, pair, side, amount, client_order_id=""):
        self.orders.append((pair, side, amount, client_order_id))
        if side == "SELL":
            if pair.startswith("BTC-"):
                self.btc -= amount
            elif pair.startswith("ETH-"):
                self.eth -= amount
        response = {
            "orderId": "one", "status": "FILLED", "executedQty": str(amount),
            "cummulativeQuoteQty": str(amount * Decimal("65000")),
            "fills": [{
                "price": "65000", "qty": str(amount),
                "commission": "0", "commissionAsset": "BNB",
            }],
        }
        self.responses[client_order_id] = response
        return response

    def order_by_client_id(self, pair, client_order_id):
        return self.responses.get(client_order_id)


def test_dca_integrity_flatten_includes_managed_inventory_when_net_base_is_zero():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        managed = root / "managed_inventory.json"
        managed.write_text(json.dumps({
            "pairs": {"BTC-USDT": {"managed_base": "0.0015"}},
        }), encoding="utf-8")
        guard = Guard.__new__(Guard)
        guard.managed_inventory_path = managed
        guard.state_path = root / "guard_state.json"
        guard.state = {"bots": {"bot": {
            "managed_base_target": "0.0015", "tripped_at": 100,
            "emergency_adjustments": [],
        }}}
        guard.emergency_exchange = Exchange()
        guard.inventory_ledger = UnifiedInventoryLedger(root / "shared")
        seed_ownership(guard.inventory_ledger, btc="0.0015")
        guard._lot_filter = lambda pair: (Decimal("0.00001"), Decimal("5"))
        guard._save = lambda: None
        result = guard._flatten({
            "pair": "BTC-USDT", "net_base": "0", "mark_price": "65000",
        }, "bot")
        assert result["exit_complete"]
        assert result["amount"] == "0.0015"
        assert guard.emergency_exchange.orders[0][2] == Decimal("0.0015")


def test_existing_latch_is_marked_pending_manual_without_order():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        managed = root / "managed_inventory.json"
        managed.write_text(json.dumps({
            "pairs": {"BTC-USDT": {"managed_base": "0.0015"}},
        }), encoding="utf-8")
        guard = Guard.__new__(Guard)
        guard.managed_inventory_path = managed
        guard.state = {"bots": {"dca-live-btcusdt-200": {
            "managed_base_target": "0.0015", "latest": {"net_base": "0"},
            "action_complete": True, "flatten_response": {"status": "not_required"},
            "recovery": {"phase": LATCHED, "exit_completed_at": None},
        }}}
        guard._migrate_incomplete_latched_inventory()
        bot = guard.state["bots"]["dca-live-btcusdt-200"]
        assert not bot["action_complete"]
        assert bot["manual_exit_required"]
        assert bot["exit_status"] == "pending_manual_existing_dca_inventory"


def test_first_unattributed_liquidation_honors_approved_cap_and_settles_usdt():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        guard = Guard.__new__(Guard)
        guard.inventory_ledger = UnifiedInventoryLedger(root / "shared")
        seed_ownership(guard.inventory_ledger, btc="0.0015")
        guard.inventory_ledger.set_bootstrap_caps({"BTC": "0.00155"}, now=1)
        guard.emergency_exchange = Exchange("0.004")
        guard.notification_path = root / "events.jsonl"
        guard._lot_filter = lambda pair: (Decimal("0.00001"), Decimal("5"))
        guard._price = lambda pair: Decimal("65000")
        row = {
            "owned_total": "0.0015",
            "unattributed": "0.0025",
            "confirmation": {"cycles": 3, "confirmed": True},
        }
        guard._liquidate_unattributed("BTC", row, "evidence")
        assert len(guard.emergency_exchange.orders) == 1
        pair, side, amount, client_id = guard.emergency_exchange.orders[0]
        assert (pair, side, amount) == ("BTC-USDT", "SELL", Decimal("0.00155"))
        assert client_id.startswith("inv-")
        assert guard.inventory_ledger.bootstrap_cap("BTC") is None


def test_notification_failure_cannot_rewrite_completed_fill_or_reuse_cap():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        guard = Guard.__new__(Guard)
        guard.inventory_ledger = UnifiedInventoryLedger(root / "shared")
        seed_ownership(guard.inventory_ledger, btc="0.0015")
        guard.inventory_ledger.set_bootstrap_caps({"BTC": "0.00155"}, now=1)
        guard.emergency_exchange = Exchange("0.004")
        guard.notification_path = root / "events.jsonl"
        guard._lot_filter = lambda pair: (Decimal("0.00001"), Decimal("5"))
        guard._price = lambda pair: Decimal("65000")
        original_append = dca_live_guard.append_event

        def fail_completed_event(path, event):
            if event["transition"] == "INVENTORY_LIQUIDATION_COMPLETED":
                raise OSError("simulated notification disk failure")
            return original_append(path, event)

        with patch("dca_live_guard.append_event", side_effect=fail_completed_event):
            try:
                guard._liquidate_unattributed("BTC", {
                    "owned_total": "0.0015", "unattributed": "0.0025",
                    "confirmation": {"cycles": 3, "confirmed": True},
                }, "evidence")
            except OSError as exc:
                assert "notification" in str(exc)
            else:
                raise AssertionError("notification failure should remain observable")
        with guard.inventory_ledger._connection() as connection:
            job = dict(connection.execute(
                "SELECT * FROM liquidation_jobs WHERE scope='unattributed'"
            ).fetchone())
        assert job["status"] == "COMPLETED"
        assert guard.inventory_ledger.completed_job_verified(job)
        assert guard.inventory_ledger.bootstrap_cap("BTC") is None
        assert len(guard.emergency_exchange.orders) == 1
        assert len(guard.inventory_ledger.pending_events()) == 1
        assert guard._flush_inventory_events() == 1
        assert guard.inventory_ledger.pending_events() == []


def test_unattributed_below_minimum_is_persisted_as_dust_without_order():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        guard = Guard.__new__(Guard)
        guard.inventory_ledger = UnifiedInventoryLedger(root / "shared")
        seed_ownership(guard.inventory_ledger, eth="0.0505285")
        guard.inventory_ledger.set_bootstrap_caps({"ETH": "0.0022715"}, now=1)
        guard.emergency_exchange = Exchange("0")
        guard.emergency_exchange.account_balances = lambda: balances("0", "0.0528")
        guard.emergency_exchange.open_orders = lambda pair: [{"orderId": "active"}]
        guard.notification_path = root / "events.jsonl"
        guard._lot_filter = lambda pair: (Decimal("0.0001"), Decimal("5"))
        guard._price = lambda pair: Decimal("1926")
        row = {
            "owned_total": "0.0505285", "unattributed": "0.0022715",
            "confirmation": {"cycles": 3, "confirmed": True},
        }
        guard._liquidate_unattributed("ETH", row, "evidence")
        assert guard.emergency_exchange.orders == []
        with guard.inventory_ledger._connection() as connection:
            job = connection.execute(
                "SELECT status,error FROM liquidation_jobs"
            ).fetchone()
        assert job["status"] == "DUST"
        assert "minimum_notional=5" in job["error"]
